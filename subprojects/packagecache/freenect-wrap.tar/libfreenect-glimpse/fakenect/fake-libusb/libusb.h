#pragma once

typedef struct _libusb_device_handle libusb_device_handle;
typedef struct _libusb_context libusb_context;
